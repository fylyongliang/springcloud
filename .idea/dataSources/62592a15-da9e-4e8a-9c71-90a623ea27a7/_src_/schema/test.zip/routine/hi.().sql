CREATE PROCEDURE hi()
  select 'hello';
